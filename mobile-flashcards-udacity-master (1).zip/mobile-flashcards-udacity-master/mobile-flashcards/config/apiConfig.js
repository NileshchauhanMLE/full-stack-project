export const url = 'https://mobile-flashcards-udacity-api.herokuapp.com'
export const headers = {
	'Authorization': 'auth',
	'Content-Type': 'application/json'
}