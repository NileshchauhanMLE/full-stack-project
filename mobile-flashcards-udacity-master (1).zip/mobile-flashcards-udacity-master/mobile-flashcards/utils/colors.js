// bootstrap colors
export const primary 		= '#007bff'
export const secondary 	= '#6c757d'
export const success 		= '#28a745'
export const danger 		= '#dc3545'
export const warning 		= '#d39e00'
export const info 			= '#17a2b8'
export const light 			= '#f8f9fa'
export const dark 			= '#343a40'